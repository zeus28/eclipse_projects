package com.marakana.contacts.repositories;
//import javax.persistence.EntityManager;
//import javax.persistence.Persistence;
import com.marakana.contacts.entities.Address;
public class AddressRepository extends Repository<Address> {

	
	public AddressRepository() {
		super(Address.class);
	}
	
	

	

}
